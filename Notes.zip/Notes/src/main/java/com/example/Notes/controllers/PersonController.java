package com.example.Notes.controllers;


import com.example.Notes.DTO.PersonDTO;
import com.example.Notes.DTO.PersonFullInfoDTO;
import com.example.Notes.models.Person;
import com.example.Notes.service.NoteService;
import com.example.Notes.service.PersonService;
import com.example.Notes.util.PersonEmailValidator;
import com.example.Notes.util.PersonValidatorUsername;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/person")
@RequiredArgsConstructor
@Tag(name="Пользователи", description="Работа с пользователями")
public class PersonController {

    private final PersonService personService;

    private final PersonValidatorUsername personValidatorUsername;

    private final PersonEmailValidator personEmailValidator;

    private final NoteService noteService;

    private final ModelMapper modelMapper;

    @GetMapping()
    @SecurityRequirement(name = "BearerAuth")
    @Operation(
            summary = "Вывод всех пользователей",
            description = "Позволяет вывести всех пользователей системы"
    )
    public ResponseEntity<List<PersonFullInfoDTO>> findAllPerson() {
        List<PersonFullInfoDTO> personDTOS =
                personService.getAllPerson()
                        .stream().map(this::convertToPersonFullInfo)
                        .collect(Collectors.toList());
        return new ResponseEntity<>(personDTOS, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    @Operation(
            summary = "Вывод пользователя с определенным id",
            description = "Позволяет вывести конкретного пользователя"
    )
    public ResponseEntity<PersonFullInfoDTO> getOnePerson(@PathVariable Long id) {
        Person person = personService.getOnePerson(id);
        PersonFullInfoDTO personFullInfoDTO = convertToPersonFullInfo(person);
        return new ResponseEntity<>(personFullInfoDTO, HttpStatus.OK);
    }


    @PostMapping("/update/{id}")
    @GetMapping("/{id}")
    @Operation(
            summary = "Редактирование пользователя с определенным id",
            description = "Позволяет редактировать профиль конкретного пользователя"
    )
    public ResponseEntity<HttpStatus> updatePerson(@RequestBody @Valid PersonDTO personDTO,
                                                   BindingResult bindingResult, @PathVariable Long id) {
        personValidatorUsername.validate(personDTO, bindingResult);
        personEmailValidator.validate(personDTO, bindingResult);
        if(bindingResult.hasErrors()) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        personService.updatePerson(id,convertToPerson(personDTO));
        return ResponseEntity.ok(HttpStatus.OK);
    }

    @DeleteMapping("/delete/{id}")
    @Operation(
            summary = "Удаление пользователя с определенным id",
            description = "Позволяет удалять конкретного пользователя"
    )
    public ResponseEntity<HttpStatus> deletePerson(@PathVariable Long id) {
        personService.deletePerson(id);
        return ResponseEntity.ok(HttpStatus.OK);
    }

    private Person convertToPerson(PersonDTO personDTO) {
        return modelMapper.map(personDTO, Person.class);
    }

    private PersonFullInfoDTO convertToPersonFullInfo(Person person) {
        return modelMapper.map(person, PersonFullInfoDTO.class);
    }
    private PersonDTO convertToPersonDTO(Person person) {
        return modelMapper.map(person, PersonDTO.class);
    }
}
