package com.example.Notes.DTO;

import lombok.Data;

@Data
public class PersonFullInfoDTO {

    private String username;
    private String email;
}
