package com.example.Notes.DTO;

import lombok.Data;

@Data
public class PersonDTO {

    private String username;
    private String email;
    private String password;
}
